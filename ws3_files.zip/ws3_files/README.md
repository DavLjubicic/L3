# Printing Pascal's Triangle

This is a small Python program that prints Pascal's triangle.

## Usage

`python pascal.py [<number of rows>]`
